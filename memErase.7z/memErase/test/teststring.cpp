#include <cstring>
#include <iostream>
#include <string>
#include "devicelist.h"
using namespace std;

int main(){
	string * drives;
	drives = systemConnectedDrives();
	cout << *drives << endl;
	return 0;
}
