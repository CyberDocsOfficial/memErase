# memErase
This Tool will erase the memory deeply. So no one can retrieve the data.
